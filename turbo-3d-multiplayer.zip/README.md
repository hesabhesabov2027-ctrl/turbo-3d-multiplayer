# Turbo 3D — Online Multiplayer

Telefon üçün HTML, CSS, JavaScript, Three.js, Node.js və Socket.IO ilə 3D yarış prototipi.

## Lokal işə salma
1. Node.js LTS quraşdır: https://nodejs.org/
2. Terminalda layihə qovluğuna keç.
3. `npm install`
4. `npm start`
5. `http://localhost:3000` aç.

## İnternetdə yayımlama
GitHub kodu saxlayır, amma GitHub Pages Node.js Socket.IO serverini işlətmir. Layihəni Node.js dəstəkləyən hostingə (məsələn Render, Railway və ya VPS) yerləşdir:
- Build command: `npm install`
- Start command: `npm start`
- Hostinqin verdiyi ictimai linki dostlarına göndər.

## Qeyd
Bu, öyrənmə prototipidir. Toqquşma, dövrə/finiş sistemi, hesab sistemi və anti-cheat hələ əlavə edilməyib. İctimai oyunda vacib fizika və hesablamalar serverdə yoxlanmalıdır.
