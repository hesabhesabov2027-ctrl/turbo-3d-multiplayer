const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, "..", "public")));
const players = new Map();
const colors = [0x38bdf8, 0xf97316, 0xa78bfa, 0xfacc15, 0xfb7185, 0x4ade80];

io.on("connection", socket => {
  const p = { id: socket.id, name: "Sürücü-" + socket.id.slice(0,4), x: 0, z: 0, speed: 0, color: colors[Math.floor(Math.random()*colors.length)] };
  players.set(socket.id, p);
  socket.emit("welcome", { id: socket.id });
  io.emit("players", [...players.values()]);
  socket.on("setName", name => {
    if (typeof name !== "string") return;
    name = name.trim().slice(0,16);
    if (name) p.name = name;
    io.emit("players", [...players.values()]);
  });
  socket.on("drive", d => {
    if (!d || typeof d.x !== "number" || typeof d.z !== "number") return;
    p.x = Math.max(-8, Math.min(8, d.x));
    p.z = Math.max(-100000, Math.min(100000, d.z));
    p.speed = Math.max(0, Math.min(260, Number(d.speed) || 0));
    io.emit("players", [...players.values()]);
  });
  socket.on("disconnect", () => {
    players.delete(socket.id);
    io.emit("players", [...players.values()]);
  });
});
const PORT = process.env.PORT || 3000;
server.listen(PORT, "0.0.0.0", () => console.log("Turbo 3D server on port " + PORT));
