import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js";
const socket = window.io(), mount = document.getElementById("game");
const connectionEl = document.getElementById("connection"), rankingEl = document.getElementById("ranking");
const nameInput = document.getElementById("playerName");
let myId=null, players=[], steer=0, speed=0, distance=0, nitroHeld=false, lastSend=0, lastTime=performance.now();

const scene=new THREE.Scene(); scene.background=new THREE.Color(0x8ac7f2); scene.fog=new THREE.Fog(0x8ac7f2,45,180);
const camera=new THREE.PerspectiveCamera(62,1,.1,500); camera.position.set(0,5.6,10.5); camera.lookAt(0,.7,-12);
const renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.8)); renderer.shadowMap.enabled=true; renderer.outputColorSpace=THREE.SRGBColorSpace; mount.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xdff2ff,0x4b6240,2));
const sun=new THREE.DirectionalLight(0xffffff,2.3); sun.position.set(-7,14,8); sun.castShadow=true; scene.add(sun);
const mat=(c,r=.8)=>new THREE.MeshStandardMaterial({color:c,roughness:r});
const road=new THREE.Mesh(new THREE.PlaneGeometry(17,260),mat(0x343b45)); road.rotation.x=-Math.PI/2; road.position.set(0,0,-95); road.receiveShadow=true; scene.add(road);
const grass=new THREE.Mesh(new THREE.PlaneGeometry(300,300),mat(0x39834c)); grass.rotation.x=-Math.PI/2; grass.position.set(0,-.08,-90); grass.receiveShadow=true; scene.add(grass);
const markers=[];
for(let z=20;z>-220;z-=10) for(const x of [-2.83,2.83]){const m=new THREE.Mesh(new THREE.BoxGeometry(.12,.025,4.5),mat(0xf8fafc));m.position.set(x,.02,z);scene.add(m);markers.push(m);}
for(let z=12;z>-210;z-=13) for(const side of [-1,1]){
 const x=side*(11+Math.random()*7), tz=z+Math.random()*5;
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.16,.24,1.4,6),mat(0x795036));trunk.position.set(x,.7,tz);scene.add(trunk);
 const crown=new THREE.Mesh(new THREE.ConeGeometry(1.6,2.7,7),mat([0x176b43,0x21804b,0x2d9153][Math.floor(Math.random()*3)]));crown.position.set(x,2.5,tz);scene.add(crown);
}
const glass=new THREE.MeshStandardMaterial({color:0x9de4ff,metalness:.2,roughness:.25}), dark=mat(0x111827);
function createCar(color=0x38bdf8){
 const g=new THREE.Group(), body=new THREE.Mesh(new THREE.BoxGeometry(1.45,.48,2.7),mat(color,.35));body.position.y=.55;body.castShadow=true;g.add(body);
 const hood=new THREE.Mesh(new THREE.BoxGeometry(1.22,.18,.72),mat(color,.3));hood.position.set(0,.82,-.72);g.add(hood);
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.03,.48,1.15),glass);cabin.position.set(0,.91,.22);g.add(cabin);
 for(const x of [-.78,.78])for(const z of [-.83,.83]){const w=new THREE.Mesh(new THREE.BoxGeometry(.26,.42,.56),dark);w.position.set(x,.35,z);g.add(w);}
 scene.add(g);return g;
}
const myCar=createCar(0x168cff);myCar.position.set(0,0,4);const remoteCars=new Map();
function resize(){const w=mount.clientWidth,h=mount.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
new ResizeObserver(resize).observe(mount);resize();

socket.on("connect",()=>{myId=socket.id;connectionEl.textContent="● Online serverə qoşuldun";connectionEl.classList.add("online");});
socket.on("disconnect",()=>{connectionEl.textContent="● Bağlantı kəsildi...";connectionEl.classList.remove("online");});
socket.on("welcome",d=>myId=d.id);
socket.on("players",incoming=>{
 players=incoming||[];const ids=new Set(players.map(p=>p.id));
 for(const [id,car] of remoteCars)if(!ids.has(id)){scene.remove(car);remoteCars.delete(id);}
 for(const p of players){if(p.id===myId)continue;if(!remoteCars.has(p.id))remoteCars.set(p.id,createCar(p.color||0xf97316));
 const car=remoteCars.get(p.id);car.userData.tx=p.x;car.userData.tz=Math.max(-120,Math.min(15,p.z-distance/1.5));}
 renderRanking();
});
document.getElementById("saveName").onclick=()=>socket.emit("setName",nameInput.value);
nameInput.onkeydown=e=>{if(e.key==="Enter")socket.emit("setName",nameInput.value);};
const left=document.getElementById("left"),right=document.getElementById("right"),nitro=document.getElementById("nitro");
left.onpointerdown=e=>{e.preventDefault();steer=-1};right.onpointerdown=e=>{e.preventDefault();steer=1};
for(const b of [left,right])for(const ev of ["pointerup","pointercancel","pointerleave"])b.addEventListener(ev,()=>steer=0);
nitro.onpointerdown=e=>{e.preventDefault();nitroHeld=true};for(const ev of ["pointerup","pointercancel","pointerleave"])nitro.addEventListener(ev,()=>nitroHeld=false);
window.addEventListener("keydown",e=>{if(e.key==="ArrowLeft"||e.key.toLowerCase()==="a")steer=-1;if(e.key==="ArrowRight"||e.key.toLowerCase()==="d")steer=1;if(e.key===" "||e.key==="ArrowUp")nitroHeld=true;});
window.addEventListener("keyup",e=>{if(["ArrowLeft","ArrowRight","a","d"].includes(e.key))steer=0;if(e.key===" "||e.key==="ArrowUp")nitroHeld=false;});
function renderRanking(){
 const sorted=[...players].sort((a,b)=>b.z-a.z);rankingEl.innerHTML="";
 if(!sorted.length){rankingEl.innerHTML="<li>Hələ oyunçu yoxdur.</li>";return;}
 sorted.forEach((p,i)=>{const li=document.createElement("li");li.textContent=`${i+1}. ${p.name} — ${Math.floor(Math.max(0,p.z))} m`;if(p.id===myId)li.className="me";rankingEl.appendChild(li);});
 const pos=sorted.findIndex(p=>p.id===myId);document.getElementById("position").textContent=pos>=0?`${pos+1}/${sorted.length}`:"—";
}
function animate(now){
 requestAnimationFrame(animate);const dt=Math.min((now-lastTime)/1000,.05);lastTime=now;
 speed+=( (nitroHeld?48:31)-speed)*Math.min(1,dt*.65);distance+=speed*dt*2.3;
 myCar.position.x=THREE.MathUtils.clamp(myCar.position.x+steer*dt*(4.8+speed*.06),-7.1,7.1);
 myCar.rotation.z=THREE.MathUtils.lerp(myCar.rotation.z,-steer*.12,dt*8);myCar.position.y=Math.sin(now*.008)*.025;
 for(const m of markers){m.position.z+=speed*dt*1.9;if(m.position.z>25)m.position.z-=240;}
 for(const car of remoteCars.values()){car.position.x=THREE.MathUtils.lerp(car.position.x,car.userData.tx??0,dt*4);car.position.z=THREE.MathUtils.lerp(car.position.z,car.userData.tz??-25,dt*4);}
 camera.position.x=THREE.MathUtils.lerp(camera.position.x,myCar.position.x*.28,dt*2);camera.lookAt(myCar.position.x*.18,.7,-12);
 document.getElementById("speed").textContent=Math.round(speed*4);document.getElementById("distance").textContent=Math.floor(distance);
 if(now-lastSend>150&&socket.connected){socket.emit("drive",{x:myCar.position.x,z:distance,speed:Math.round(speed*4)});lastSend=now;}
 renderer.render(scene,camera);
}
requestAnimationFrame(animate);
